import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { GreetingService } from './services/greeting.service';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = 'frontend';
  greeting: string = '';
  loading: boolean = true;
  error: string = '';

  constructor(private greetingService: GreetingService) { }

  ngOnInit(): void {
    this.greetingService.getGreeting().subscribe({
      next: (data) => {
        this.greeting = data;
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load greeting from backend';
        this.loading = false;
        console.error('Error fetching greeting:', err);
      }
    });
  }
}
