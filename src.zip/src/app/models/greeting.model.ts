export interface GreetingResponse {
  message: string;
  timestamp: number;
  status: string;
}

export interface ApiResponse<T> {
  data?: T;
  error?: string;
  timestamp: number;
}

