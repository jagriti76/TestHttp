import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { ConfigService } from './config.service';
import { GreetingResponse } from '../models/greeting.model';

/**
 * Service for greeting operations.
 * Enterprise patterns implemented:
 * - Dependency injection
 * - Error handling
 * - Retry logic
 * - Centralized configuration
 */
@Injectable({
  providedIn: 'root'
})
export class GreetingService {

  constructor(
    private http: HttpClient,
    private config: ConfigService
  ) { }

  /**
   * Get simple greeting message
   * Includes retry logic for resilience
   */
  getGreeting(): Observable<string> {
    const url = this.config.getApiUrl('/greeting');
    return this.http.get(url, { responseType: 'text' }).pipe(
      retry(2), // Retry failed requests up to 2 times
      catchError(this.handleError)
    );
  }

  /**
   * Get detailed greeting with metadata
   * Uses typed response model
   */
  getDetailedGreeting(): Observable<GreetingResponse> {
    const url = this.config.getApiUrl('/greeting/detailed');
    return this.http.get<GreetingResponse>(url).pipe(
      retry(2),
      catchError(this.handleError)
    );
  }

  /**
   * Get personalized greeting
   * @param name - Name to personalize greeting
   */
  getPersonalizedGreeting(name?: string): Observable<GreetingResponse> {
    let url = this.config.getApiUrl('/greeting/personalized');
    if (name) {
      url += `?name=${encodeURIComponent(name)}`;
    }
    return this.http.get<GreetingResponse>(url).pipe(
      retry(2),
      catchError(this.handleError)
    );
  }

  /**
   * Centralized error handling
   * Enterprise pattern: Consistent error handling
   */
  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'An unknown error occurred';

    if (error.error instanceof ErrorEvent) {
      // Client-side or network error
      errorMessage = `Client Error: ${error.error.message}`;
    } else {
      // Backend error
      errorMessage = `Server Error: ${error.status} - ${error.message}`;
    }

    console.error('Error in GreetingService:', errorMessage);
    return throwError(() => new Error(errorMessage));
  }
}
