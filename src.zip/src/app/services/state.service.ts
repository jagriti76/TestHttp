import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

/**
 * Service for managing application-wide state.
 * Enterprise pattern: Centralized state management
 */
@Injectable({
  providedIn: 'root'
})
export class StateService {
  private loadingSubject = new Subject<boolean>();
  private errorSubject = new Subject<string | null>();

  loading$ = this.loadingSubject.asObservable();
  error$ = this.errorSubject.asObservable();

  constructor() { }

  setLoading(loading: boolean): void {
    this.loadingSubject.next(loading);
  }

  setError(error: string | null): void {
    this.errorSubject.next(error);
  }

  clearError(): void {
    this.errorSubject.next(null);
  }
}

