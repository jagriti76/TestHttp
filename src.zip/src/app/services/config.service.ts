import { Injectable } from '@angular/core';

/**
 * Configuration service for API endpoints.
 * Enterprise pattern: Centralized configuration management
 */
@Injectable({
  providedIn: 'root'
})
export class ConfigService {
  private readonly API_BASE_URL = 'http://localhost:8080';
  private readonly API_PREFIX = '/api';

  constructor() { }

  /**
   * Get the full API URL for a given endpoint
   */
  getApiUrl(endpoint: string): string {
    return `${this.API_BASE_URL}${this.API_PREFIX}${endpoint}`;
  }

  /**
   * Get API base URL
   */
  getBaseUrl(): string {
    return this.API_BASE_URL;
  }
}

