export const environment = {
  production: true,
  apiUrl: 'https://your-production-api.com',
  apiPrefix: '/api',
  retryAttempts: 3,
  timeout: 60000
};

