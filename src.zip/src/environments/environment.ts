export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080',
  apiPrefix: '/api',
  retryAttempts: 2,
  timeout: 30000
};

