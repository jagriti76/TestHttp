package com.example.fullstack.controller;

import com.example.fullstack.dto.GreetingResponse;
import com.example.fullstack.service.GreetingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST Controller for greeting operations.
 * Follows enterprise architecture patterns:
 * - Thin controller (delegates to service layer)
 * - Uses DTOs for response contracts
 * - Proper CORS configuration
 * - ResponseEntity for HTTP responses
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = {"http://localhost:4200", "http://localhost:3000"})
public class GreetingController {

    private final GreetingService greetingService;

    @Autowired
    public GreetingController(GreetingService greetingService) {
        this.greetingService = greetingService;
    }

    /**
     * Get greeting message endpoint.
     * 
     * @return ResponseEntity with greeting message
     */
    @GetMapping("/greeting")
    public ResponseEntity<String> getGreeting() {
        String greeting = greetingService.getGreeting();
        return ResponseEntity.ok(greeting);
    }

    /**
     * Get structured greeting response with metadata.
     * Enterprise pattern: Using DTOs for structured responses
     * 
     * @return ResponseEntity with GreetingResponse DTO
     */
    @GetMapping("/greeting/detailed")
    public ResponseEntity<GreetingResponse> getDetailedGreeting() {
        String greeting = greetingService.getGreeting();
        GreetingResponse response = new GreetingResponse(greeting);
        return ResponseEntity.ok(response);
    }

    /**
     * Get personalized greeting.
     * 
     * @param name the name to greet (optional)
     * @return ResponseEntity with personalized greeting
     */
    @GetMapping("/greeting/personalized")
    public ResponseEntity<GreetingResponse> getPersonalizedGreeting(
            @RequestParam(required = false) String name) {
        String greeting = greetingService.getPersonalizedGreeting(name);
        GreetingResponse response = new GreetingResponse(greeting);
        return ResponseEntity.ok(response);
    }
}


