package com.example.fullstack.service;

import org.springframework.stereotype.Service;

/**
 * Service layer for greeting operations.
 * Implements business logic following enterprise architecture patterns.
 */
@Service
public class GreetingService {

    /**
     * Retrieves a greeting message.
     * In an enterprise application, this would typically:
     * - Call repository layer for data
     * - Apply business rules and validations
     * - Transform data as needed
     * 
     * @return greeting message
     */
    public String getGreeting() {
        // Business logic can be added here
        return "hi jagriti";
    }

    /**
     * Retrieves a personalized greeting message.
     * 
     * @param name the name to greet
     * @return personalized greeting message
     */
    public String getPersonalizedGreeting(String name) {
        if (name == null || name.trim().isEmpty()) {
            return getGreeting();
        }
        return "hi " + name;
    }
}

