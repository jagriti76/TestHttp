package com.example.fullstack.dto;

/**
 * Data Transfer Object for API responses.
 * Follows enterprise pattern for clean API contracts.
 */
public class GreetingResponse {
    
    private String message;
    private long timestamp;
    private String status;

    public GreetingResponse() {
        this.timestamp = System.currentTimeMillis();
        this.status = "SUCCESS";
    }

    public GreetingResponse(String message) {
        this();
        this.message = message;
    }

    // Getters and Setters
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

