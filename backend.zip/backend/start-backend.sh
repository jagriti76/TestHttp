#!/bin/bash

echo "Starting Spring Boot Backend..."
echo "================================"
echo ""

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "Error: Java is not installed."
    echo "Please install Java 17 or higher:"
    echo "  - Download from: https://adoptium.net/"
    exit 1
fi

echo "Running Spring Boot application with Gradle..."
echo "Backend will be available at: http://localhost:8080"
echo "API endpoint: http://localhost:8080/api/greeting"
echo ""

./gradlew bootRun

